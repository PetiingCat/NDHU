<?php
  $x1=$_GET["V01"];
  $x2=$_GET["V02"];
  echo $x1+$x2;
?>

