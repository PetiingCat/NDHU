<?php
  $a1=$_POST["f001"];
  $a2=$_POST["f002"];
  echo $a1.$a2;

?>